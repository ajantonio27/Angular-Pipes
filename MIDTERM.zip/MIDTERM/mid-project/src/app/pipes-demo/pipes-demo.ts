import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Observable, interval, of } from 'rxjs';
import { map, delay } from 'rxjs/operators';

@Component({
  selector: 'app-pipes-demo',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pipes-demo.html',
  styleUrls: ['./pipes-demo.css']
})
export class PipesDemo {
  // Date Pipes Data
  currentDate: Date = new Date();

  // Async Pipes Data
  promiseData: Promise<string> = new Promise((resolve) => {
    setTimeout(() => resolve('✅ Data successfully loaded from Promise!'), 2000);
  });

  observableData: Observable<string> = of('🎉 Data received from Observable!').pipe(
    delay(1000)
  );

  timer$: Observable<Date> = interval(1000).pipe(
    map(() => new Date())
  );

  userData$: Observable<string> = of('User: John Doe | Role: Developer').pipe(
    delay(1500)
  );

  // Slice Pipes Data
  fruits: string[] = [
    'Apple',
    'Banana',
    'Orange',
    'Mango',
    'Grapes',
    'Strawberry',
    'Pineapple',
    'Watermelon'
  ];

  longText: string = 'Angular pipes are a powerful feature that allows you to transform data in templates. They are simple to use and help keep your component code clean and focused on business logic rather than data formatting.';

  // Currency Pipes Data
  price: number = 1234.56;
  largeAmount: number = 1500000.75;

  // Decimal Pipes Data
  decimalNumber: number = 3.14159265359;
  percentage: number = 0.856;

  // UpperCase/LowerCase Pipes Data
  sampleText: string = 'Angular Is Awesome!';
  mixedText: string = 'ThIs Is A MiXeD CaSe TeXt ExAmPlE';

  // JSON Pipe Data
  userObject = {
    name: 'Aaron Antonio',
    age: 21,
    email: 'aaronantonio@gmail.com',
    role: 'Front End Developer',
    active: true
  };

  complexObject = {
    id: 101,
    product: 'Laptop',
    specs: {
      processor: 'Intel i7',
      ram: '16GB',
      storage: '512GB SSD'
    },
    price: 1299.99,
    inStock: true
  };

  // KeyValue Pipe Data
  productDetails = {
    productName: 'MacBook Pro',
    brand: 'Apple',
    price: '$2,499',
    color: 'Space Gray',
    year: 2024,
    warranty: '1 Year'
  };
}
